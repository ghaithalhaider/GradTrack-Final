/**
 * Handles cascading selects for University -> College -> Department.
 * 
 * Usage:
 * Import this function and call it with the IDs of the three select elements.
 * initializeCascadingSelects('universitySelectId', 'collegeSelectId', 'departmentSelectId');
 */

export async function initializeCascadingSelects(universityId, collegeId, departmentId, dataPath = 'university_data.json') {
    const universitySelect = document.getElementById(universityId);
    const collegeSelect = document.getElementById(collegeId);
    const departmentSelect = document.getElementById(departmentId);

    if (!universitySelect || !collegeSelect || !departmentSelect) {
        console.error("One or more select elements not found:", { universityId, collegeId, departmentId });
        return;
    }

    // Load Data
    let universityData = {};
    try {
        const response = await fetch(dataPath);
        if (!response.ok) throw new Error(`Failed to load university_data.json from ${dataPath}`);
        universityData = await response.json();
    } catch (error) {
        console.error("Error loading university data:", error);
        return;
    }

    // Initialize University Options
    // Keep the first "default" option if it exists
    const defaultUniOption = universitySelect.firstElementChild;
    universitySelect.innerHTML = '';
    if (defaultUniOption) universitySelect.appendChild(defaultUniOption);

    Object.keys(universityData).forEach(uni => {
        const option = document.createElement('option');
        option.value = uni;
        option.textContent = uni;
        universitySelect.appendChild(option);
    });

    // Reset and Disable Helper
    const resetSelect = (select, defaultText) => {
        select.innerHTML = `<option value="" disabled selected>${defaultText}</option>`;
        select.disabled = true;
    };

    // Event Listeners
    universitySelect.addEventListener('change', () => {
        const selectedUni = universitySelect.value;

        // Reset dependent fields
        resetSelect(collegeSelect, 'اختر الكلية...');
        resetSelect(departmentSelect, 'اختر القسم...');

        if (selectedUni && universityData[selectedUni]) {
            collegeSelect.disabled = false;
            const colleges = Object.keys(universityData[selectedUni]);
            colleges.forEach(col => {
                const option = document.createElement('option');
                option.value = col;
                option.textContent = col;
                collegeSelect.appendChild(option);
            });
        }
    });

    collegeSelect.addEventListener('change', () => {
        const selectedUni = universitySelect.value;
        const selectedCol = collegeSelect.value;

        // Reset dependent field
        resetSelect(departmentSelect, 'اختر القسم...');

        if (selectedUni && selectedCol && universityData[selectedUni][selectedCol]) {
            departmentSelect.disabled = false;
            const departments = universityData[selectedUni][selectedCol];
            departments.forEach(dept => {
                const option = document.createElement('option');
                option.value = dept;
                option.textContent = dept;
                departmentSelect.appendChild(option);
            });
        }
    });
}
